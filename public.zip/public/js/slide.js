var swiper = new Swiper(".mySwiper", {
    spaceBetween: 30,
    centeredSlides: true,
    effect:'fade',
    autoplay: {
      delay: 2500,
      disableOnInteraction: false,
    }
  });